package com.atguigu.gmall.publisher;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GmallPublisher2022ApplicationTests {

    void contextLoads() {
    }

}
